from UI import UI


def main():
    ui = UI()
    ui.run()


if __name__ == '__main__':
    main()
